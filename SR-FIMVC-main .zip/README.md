﻿# SR-FIMVC：结构约束 Z 更新修订版

这是基于当前已修复代码建立的独立修订版。原桌面目录未覆盖。本版本补充式（9b）的 Z 子问题，不声称它就是生成已接收论文表格的原实现。

## 实现内容

固定 X_com、U、w、A、G、L，最小化：

    ||diag(w)(X_com-ZU)||_F^2 + lambda1*tr((ZA)' G L G' (ZA))

同时要求 Z 非负、每行和为 1、只使用本次高斯图初始化的非零邻域，并保留 (ZA)'(ZA)=I。lambda2*||P||^2 在这个子问题中为常数，无需加入求解器。

- solve_structural_alignment.m：通过薄 SVD 在 Z 的稳定正秩子空间白化，求满足精确正交约束的 A；不以分母 ridge 代替约束。秩不足时明确报错。
- update_Z_structured.m：MATLAB fmincon 内点法、解析梯度和约束雅可比、稀疏支持及线性约束，使用 L-BFGS 避免存储变量规模的稠密 Hessian。
- z_structure_objective.m、z_orthogonality_constraints.m：子问题及其导数。
- client_step_RWC.m：在锚图刷新轮计算 A 和可靠性权重，冻结这些量求 Z；新 Z 随后用于 U、P 的更新。其余轮缓存 Z/A，并继续更新 U/P。

求解器执行有限迭代，属于参考性的不精确块更新。exitflag=0 表示达到迭代上限，不能称为已经求得子问题最优解。候选解不满足约束容差时，沿原可行点方向回退；仅接收满足容差且冻结变量后的目标不增加的点。回退可能带来较小的实际步长，日志中记录 backtrack_alpha。无法接收时发出警告并保留原可行 Z。接受一次 Z 步不等于证明整个动态算法单调收敛。

## 依赖和参数

需要 MATLAB Optimization Toolbox（fmincon），缺失时明确报错，不静默换成无约束算法。

    config.structure_z_enabled = true; % 本目录默认开启
    config.lambda1 = 1.0;
    config.z_max_iter = 20;
    config.z_max_seconds = 10; % 每次求解的软时间预算，在线性代数步骤之间检查
    config.z_constraint_tol = 1e-7;

将 structure_z_enabled 设为 false，可在同一目录运行此前的已修复基线。关闭时仍使用原来的 A 求解分支。结构 Z 更新阶段曾验证开关关闭时复现基线；后续隐式图改造与 H 初始化可行化属于明确记录的新修改，不能继续把当前目录称为旧基线的逐标签复现。

每个新锚图周期更新一次 Z，内层邻域保持固定。anchor_s=1 时每行没有可优化的分配自由度；一般应使用多个邻居。保留了此前实现的 U 正规方程 ridge 及 U→P 更新顺序；P 按 Eq. (10) 使用 Omega.*X 的观测基底，均值填充仅用于初始化，不代表其他数值细节均已与论文完全统一。

## 运行

把 MATLAB 当前目录切换到本文件所在目录，执行：

    run_small_comparison

脚本在 Handwritten、PER=0.3/0.5、seed=1、3 轮、30 锚点、3 近邻下比较开关两种状态，检查缺失掩码和初始聚类一致，保存结果。该脚本用于验证修改效果，不是论文性能复现。不建议先运行原有的大规模网格搜索脚本：完整数据测试曾在第二次锚图刷新时出现病态矩阵警告和明显耗时增加，已中止那次五轮测试。当前提供的是第一轮结构更新及一次通信的三轮配对验证；后续多轮稳定性仍需验证。时间预算只在回调时检查，不是严格的墙钟上限。

R.logs.z_updates 包含每轮各视图的接收状态、求解器状态、步长、冻结子问题目标和约束误差。R.final.assign 和 R.best.assign 保存预测标签。保留了此前按真实 NMI 选最佳轮次的行为，因此报告时应区分 final 和 best。

## 保留及尚未解决的问题

- 按用户要求保留真实 NMI 的最佳轮次选择/早停，以及原 L2 归一化与缺失协议。
- H 更新默认采用论文所写目标函数的真实梯度，并通过回退保证固定其他变量时该 H 子目标不下降；paper 与 legacy 兼容模式仍可用于审计复现。
- H 的初始值现已满足 H'*H=I；每轮 H 更新也使用秩感知的正交 Procrustes 求解。代理矩阵秩亏时，在原最优解集合中选择最接近上一轮 H 的解，不给目标函数添加扰动。
- 全局共识图已改为等价隐式算子；结构约束求解仍有额外开销，不能由图运算的改善直接推出整个算法严格线性或沿用原耗时结论。
- 完整数据分支仍跳过锚补全，本次只修订含缺失数据分支。
- 此前从 Gaussian 软图得到 Z 的步骤在本版用作初始化和支持选择，最终 Z 由结构子问题修正；这需要在公开实现和补充推导中披露。

本次测试使用已修复的一对一 ACC，不应将新旧 ACC 差异全部归因于模型改变。单种子、三轮结果不足以得出稳定的性能提升或下降结论。

软时间预算会使实际迭代数受到机器速度影响，即使种子相同，数值轨迹也可能略有变化。严格复现实验需固定软件环境，并使用足够大的时间预算，主要按固定迭代上限控制求解。

## 本轮隐式全局图更新

consensus_laplacian_operator 只保存稀疏标签 Y 与度向量 d=Y(Y^T 1)。apply_graph_operator 实现 LB=d.*B-Y(Y^T B)，masked_graph_operator 实现 GLG^T 的矩阵作用。

main、client、结构对齐及结构 Z 目标/梯度的活动路径均使用该接口，不构造 YY^T、L 或 GLG^T 的 N×N 矩阵。数值矩阵输入继续支持，供小规模显式参考测试使用。旧的 build_anchor_L/build_graph_L 独立辅助文件仍在目录中，但当前主训练路径不调用它们，不能据此声称目录内每个旧辅助函数都已消除两两图。

上次结构 Z 更新的验证结果仍保存在 validation/ 中，其耗时是隐式改造前的历史数据。本轮新增验证见 validation-implicit/ 与 隐式图验证摘要.md。

## H 初始化正交可行化

initialize_latent_view.m 将“用于初始 K-Means 的数据表示”和“优化变量 H 的可行初值”分开：前者只保留数值有效的左奇异方向并对剩余列补零，后者在这些方向的正交补中用确定性候选补齐到 k 列。补齐过程不构造 N×N 零空间，也不消耗 MATLAB 随机流。

因此，即使某视图维数小于聚类数（Handwritten 第四视图为 6 维、k=10），初始 H 仍满足 H'*H=I，而人工补充的 4 个方向不参与初始 K-Means。初始化诊断写入 R.protocol.H_initialization。验证见 test_H_initialization.m、validation-H-initialization/ 与 H初始化验证摘要.md。

本项只修复初始可行性，不改变论文目标函数。随后新增的 stable_stiefel_procrustes.m 单独处理每轮 H 更新中的秩亏非唯一性，验证见 test_stable_H_update.m、validation-H-update/ 与 H更新验证摘要.md。

## H 更新的秩亏稳定化

论文的 H 子问题可写成 max tr(H'*M)，约束 H'*H=I。满秩时 stable_stiefel_procrustes.m 与原 U*V' 完全相同；数值秩为 r<k 时，先固定由非零奇异值决定的主最优部分，再在剩余最优解中最小化 ||H-H_prev||_F。若二级参考投影也秩亏，再用确定性正交补完成未确定方向。

该选择仍达到原子问题的核范数最优值 sum(svd(M))，不是给 M 加 epsilon*H_prev，也没有改变论文目标。每轮诊断保存在 R.logs.h_updates，包括数值秩、正交误差、目标差和相对上一轮距离。

## H 目标梯度修订

论文目标的二次项为 Tr(H'*A*D*H)，其中 A=K-lambda_graph*L 为对称矩阵，D=tildeK^2 为对角矩阵。由于 A 与 D 一般不交换，其真实梯度是 (A*D+D*A)*H，而论文 Eq. (13) 的 2*A*D*H 只在 A*D=D*A 时成立；旧代码还少了二次项系数 2。

update_H_representation.m 默认使用 config.h_gradient_mode='objective'，以结合律和隐式图算子分别计算 A*(D*H) 与 D*(A*H)，不构造 N×N 核或图矩阵。候选正交投影若降低论文所写 H 目标，则沿 Stiefel 投影路径回退；30 次仍无法接受时保留 H_prev。config.h_monotone_safeguard 默认开启。

兼容模式 paper 和 legacy 分别复现论文 Eq. (13) 与旧代码代理方向，便于审计，不代表它们是目标函数的正确梯度。有限差分、兼容性、单步非下降和短程三路对比见 audit_H_gradient.m、test_H_gradient_update.m、validation-H-gradient/ 与 H梯度修订与验证.md。

## 均值填充初始化与本地 Y/C 近似

论文只明确要求用均值填充视图 Xhat 初始化 H；Eq. (10) 的 P 更新仍以原始 X 为基底。当前默认 completion_init_mode='mean'：mean_fill_missing.m 严格根据 Omega 使用观测列均值初始化 X_completed，不读取缺失位置可能残留的隐藏值；首轮客户端更新后仍按 Eq. (10) 以 Omega.*X 为固定观测基底。completion_init_mode='zero' 可复现此前零填充初始化。

论文 Eq. (14) 要求 C_v'*C_v=I，但优化文字又称“计算普通质心”，两者并不等价。当前默认 local_approx_mode='orthogonal_bcd'，以明确的 Eq. (14) 为准，交替执行一热 Y 行最大化和正交 C Procrustes 更新，直到标签稳定或达到 50 次。legacy 模式保留此前单次 C-then-Y 更新。诊断写入 R.logs.local_approx_updates。

验证见 test_mean_fill_local_approximation.m、validation-mean-YC/ 与 均值填充与本地近似验证.md。单种子三轮中，均值初始化相对零填充使 ACC 在 PER=0.3 时从 93.20% 变为 92.95%，PER=0.5 时从 75.50% 变为 73.85%；正交 BCD 对这两次最终标签影响很小。这里优先保证论文定义一致，不能据这两个短程结果判断完整实验优劣。

## 服务器共识 Y/C 更新

服务器目标为 max Tr(Hc'*Y*C)，约束 Y 为逐行一热、C*C'=I。update_server_consensus.m 默认使用 server_consensus_mode='orthogonal_bcd'，交替执行行最大化与行-Stiefel Procrustes，直到标签稳定或达到 50 次；legacy 模式保留旧的一次 C-then-Y 扫描。每次通信诊断写入 R.logs.server_updates。

旧服务器在构造 Hc 前同时置换 Y_v 的列和 C_v 的行，但这种成对置换严格满足 (Y_v*P)*(P'*C_v)=Y_v*C_v，对 Hc 没有任何影响，因此活动路径已移除 Hungarian 对齐。custom_hungarian.m 作为旧辅助文件保留，但当前训练不调用。原 view_weight 只被计算和打印，从未进入目标、客户端或服务器更新，也不属于论文目标，已从活动路径删除。

验证见 test_server_consensus.m、validation-server/ 与 服务器共识验证摘要.md。Handwritten、seed=1、3 轮、PER=0.3/0.5 的服务器 BCD 都在第一次扫描达到稳定，与 legacy 结果逐标签一致；服务器目标分别增加约 299 和 281，C 行正交误差约 4e-15。
